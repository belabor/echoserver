# echoserver

A coding assignment for CY310 in MISRA C.

- multiclient support
- Timestamping
- port binding on start (22000 default)
- log file

to do:

- add addressing so it can connect someplace other then localhost
